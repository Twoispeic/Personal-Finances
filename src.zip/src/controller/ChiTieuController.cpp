#include "ChiTieuController.h"
#include "database/ChiTieuRepository.h"

ChiTieuController::ChiTieuController(NguoiDung* nd, QObject* parent)
    : QObject(parent), nguoiDung(nd)
{
    ChiTieuRepository().taoBang();
    taiLai();
}

QVariantList ChiTieuController::danhSach() const { return m_danhSach; }
QVariantList ChiTieuController::thongKeBieuDo() const { return m_thongKeBieuDo; }
QVariantList ChiTieuController::danhSachChuaXacDinh() const { return m_danhSachChuaXacDinh; }

void ChiTieuController::taiLai() {
    m_danhSach.clear();
    m_thongKeBieuDo.clear();
    m_danhSachChuaXacDinh.clear(); // Reset list mới

    ChiTieuRepository repo;
    const QList<ChiTieu> ds = repo.layTatCa(); // Thêm const để né cảnh báo của Qt

    double tongChiTieu = 0.0;

    // Hàm lambda hỗ trợ chuyển đổi mã loại sang tên hiển thị
    auto layTenLoai = [](LoaiChiTieu loai) -> QString {
        switch (loai) {
        case TIEN_SINH_HOAT: return "Tiền sinh hoạt";
        case TIEN_DIEN_NUOC:  return "Tiền điện nước";
        case TIEN_NHA:       return "Tiền nhà";
        case KHAC:           return "Khác";
        default:             return "Chưa phân loại";
        }
    };

    // Hàm lambda hỗ trợ lấy màu riêng cho từng loại chi tiêu
    // (đồng bộ với bảng màu dùng trong thongKeTheoLoai())
    auto layMauLoai = [](LoaiChiTieu loai) -> QString {
        switch (loai) {
        case TIEN_SINH_HOAT: return "#F2508C";
        case TIEN_DIEN_NUOC:  return "#FFB35C";
        case TIEN_NHA:       return "#6E7BFA";
        case KHAC:           return "#35DDC0";
        default:             return "#8A8FC0";
        }
    };

    // 1. Nạp danh sách chi tiết và phân loại
    for (const ChiTieu& ct : ds) {
        QVariantMap m;
        m["id"] = ct.getId(); // Bổ sung id để phục vụ thao tác xóa/sửa
        m["loai"] = (int)ct.getLoai();
        m["tenLoai"] = layTenLoai(ct.getLoai()); // <--- Bổ sung tên loại hiển thị
        m["mau"] = layMauLoai(ct.getLoai());     // <--- Bổ sung màu riêng cho từng loại
        m["soTien"] = ct.getSoTien();
        m["ngay"] = ct.getNgay().toString("dd/MM/yyyy");

        m_danhSach.append(m);
        tongChiTieu += ct.getSoTien();

        // Tự động nhặt các khoản "Khác" đưa vào list chưa xác định
        if (ct.getLoai() == KHAC) {
            m_danhSachChuaXacDinh.append(m);
        }
    }

    // 2. Chuẩn bị dữ liệu cho Biểu đồ tròn
    QMap<LoaiChiTieu, double> tongTheoLoai = repo.tinhTongTheoLoai();
    for (auto it = tongTheoLoai.begin(); it != tongTheoLoai.end(); ++it) {
        QVariantMap m;
        m["loai"] = (int)it.key();
        m["tenLoai"] = layTenLoai(it.key()); // <--- Bổ sung tên loại cho biểu đồ
        m["mau"] = layMauLoai(it.key());     // <--- Bổ sung màu riêng cho biểu đồ tròn/chú giải
        m["tongTien"] = it.value();

        // Tính %, tránh lỗi chia cho 0
        double phanTram = (tongChiTieu > 0) ? (it.value() / tongChiTieu) * 100.0 : 0.0;
        m["phanTram"] = phanTram;

        m_thongKeBieuDo.append(m);
    }

    emit duLieuThayDoi();
}

void ChiTieuController::them(int loai, double soTien) {
    ChiTieuRepository().them(ChiTieu((LoaiChiTieu)loai, soTien, QDate::currentDate()));
    taiLai();
}

void ChiTieuController::locTheoLoai(int loai) {
    m_danhSach.clear();
    const QList<ChiTieu> ds = ChiTieuRepository().locTheoLoai((LoaiChiTieu)loai);
    for (const ChiTieu& ct : ds) {
        QVariantMap m;
        m["loai"] = (int)ct.getLoai();
        m["soTien"] = ct.getSoTien();
        m["ngay"] = ct.getNgay().toString("dd/MM/yyyy");
        m_danhSach.append(m);
    }
    emit duLieuThayDoi();
}

void ChiTieuController::locTatCa() {
    taiLai();
}

void ChiTieuController::xoa(int id) {
    ChiTieuRepository().xoa(id);
    taiLai();
}

QVariantList ChiTieuController::thongKeTheoLoai() const {
    QVariantList ketQua;
    QMap<LoaiChiTieu, double> tong = ChiTieuRepository().tinhTongTheoLoai();

    struct TT { QString ten; QString mau; };
    QMap<LoaiChiTieu, TT> info = {
        { TIEN_SINH_HOAT, {"Tiền sinh hoạt", "#F2508C"} },
        { TIEN_DIEN_NUOC, {"Tiền điện nước", "#FFB35C"} },
        { TIEN_NHA,       {"Tiền nhà",       "#6E7BFA"} },
        { KHAC,           {"Khác",           "#35DDC0"} }
    };

    for (auto it = tong.constBegin(); it != tong.constEnd(); ++it) {
        if (it.value() <= 0) continue;
        QVariantMap m;
        m["ten"] = info[it.key()].ten;
        m["mau"] = info[it.key()].mau;
        m["soTien"] = it.value();
        ketQua.append(m);
    }
    return ketQua;
}